/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.constants;

public class AiMutex {
    public static byte PASSIVE = 1;
    public static byte LOOK = (byte)2;
    public static byte PATHING = (byte)4;
}

