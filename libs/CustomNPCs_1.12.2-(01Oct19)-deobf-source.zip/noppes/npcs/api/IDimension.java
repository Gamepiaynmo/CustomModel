/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api;

public interface IDimension {
    public int getId();

    public String getName();

    public String getSuffix();
}

