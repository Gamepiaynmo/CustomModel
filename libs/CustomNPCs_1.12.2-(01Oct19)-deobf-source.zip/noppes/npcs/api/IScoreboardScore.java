/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api;

public interface IScoreboardScore {
    public int getValue();

    public void setValue(int var1);

    public String getPlayerName();
}

