/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.item;

import noppes.npcs.api.item.IItemStack;

public interface IItemBlock
extends IItemStack {
    public String getBlockName();
}

