/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.block;

public interface ITextPlane {
    public String getText();

    public void setText(String var1);

    public int getRotationX();

    public int getRotationY();

    public int getRotationZ();

    public void setRotationX(int var1);

    public void setRotationY(int var1);

    public void setRotationZ(int var1);

    public float getOffsetX();

    public float getOffsetY();

    public float getOffsetZ();

    public void setOffsetX(float var1);

    public void setOffsetY(float var1);

    public void setOffsetZ(float var1);

    public float getScale();

    public void setScale(float var1);
}

