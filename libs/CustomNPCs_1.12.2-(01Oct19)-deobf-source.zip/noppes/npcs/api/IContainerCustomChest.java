/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api;

import noppes.npcs.api.IContainer;

public interface IContainerCustomChest
extends IContainer {
    public void setName(String var1);

    public String getName();
}

