/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.projectile.EntityArrow
 */
package noppes.npcs.api.entity;

import net.minecraft.entity.projectile.EntityArrow;
import noppes.npcs.api.entity.IEntity;

public interface IArrow<T extends EntityArrow>
extends IEntity<T> {
}

