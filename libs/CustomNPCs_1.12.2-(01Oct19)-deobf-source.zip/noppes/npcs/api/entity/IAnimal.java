/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.passive.EntityAnimal
 */
package noppes.npcs.api.entity;

import net.minecraft.entity.passive.EntityAnimal;
import noppes.npcs.api.entity.IEntityLiving;

public interface IAnimal<T extends EntityAnimal>
extends IEntityLiving<T> {
}

