/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.entity.data;

public interface INPCJob {
    public int getType();
}

