/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.entity.data;

public interface INPCAdvanced {
    public void setLine(int var1, int var2, String var3, String var4);

    public String getLine(int var1, int var2);

    public int getLineCount(int var1);

    public String getSound(int var1);

    public void setSound(int var1, String var2);
}

