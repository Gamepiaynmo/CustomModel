/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.entity.data.role;

public interface IRoleDialog {
    public String getDialog();

    public void setDialog(String var1);

    public String getOption(int var1);

    public void setOption(int var1, String var2);

    public String getOptionDialog(int var1);

    public void setOptionDialog(int var1, String var2);
}

