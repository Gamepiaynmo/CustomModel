/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.entity.data.role;

public interface IJobBard {
    public String getSong();

    public void setSong(String var1);
}

