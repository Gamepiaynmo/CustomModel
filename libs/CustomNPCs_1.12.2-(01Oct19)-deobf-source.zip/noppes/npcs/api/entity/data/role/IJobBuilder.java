/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.entity.data.role;

public interface IJobBuilder {
    public boolean isBuilding();
}

