/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.API
 */
package noppes.npcs.api.entity.data;

import net.minecraftforge.fml.common.API;

@API(owner="customnpcs", provides="Core|Entities|Data|Role", apiVersion="0.1")
interface package-info {
}

