/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.entity.data;

public interface IPixelmonPlayerData {
    public Object getParty();

    public Object getPC();
}

