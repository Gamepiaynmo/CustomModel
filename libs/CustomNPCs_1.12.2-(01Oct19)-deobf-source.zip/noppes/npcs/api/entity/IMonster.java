/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.monster.EntityMob
 */
package noppes.npcs.api.entity;

import net.minecraft.entity.monster.EntityMob;
import noppes.npcs.api.entity.IEntityLiving;

public interface IMonster<T extends EntityMob>
extends IEntityLiving<T> {
}

