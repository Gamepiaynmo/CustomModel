/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 */
package noppes.npcs.api.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import noppes.npcs.api.IPos;
import noppes.npcs.api.entity.IEntityLivingBase;

public interface IEntityLiving<T extends EntityLiving>
extends IEntityLivingBase<T> {
    public boolean isNavigating();

    public void clearNavigation();

    public void navigateTo(double var1, double var3, double var5, double var7);

    public void jump();

    @Override
    public T getMCEntity();

    public IPos getNavigationPath();
}

