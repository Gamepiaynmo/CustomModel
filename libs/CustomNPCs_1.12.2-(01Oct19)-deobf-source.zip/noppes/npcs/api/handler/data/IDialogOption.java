/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.handler.data;

public interface IDialogOption {
    public int getSlot();

    public String getName();

    public int getType();
}

