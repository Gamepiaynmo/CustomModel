/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.constants;

public class MarkType {
    public static final int NONE = 0;
    public static final int QUESTION = 1;
    public static final int EXCLAMATION = 2;
    public static final int POINTER = 3;
    public static final int SKULL = 4;
    public static final int CROSS = 5;
    public static final int STAR = 6;
}

