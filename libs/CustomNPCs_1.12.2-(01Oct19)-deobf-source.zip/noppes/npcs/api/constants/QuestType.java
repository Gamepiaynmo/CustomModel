/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.api.constants;

public class QuestType {
    public static final int ITEM = 0;
    public static final int DIALOG = 1;
    public static final int KILL = 2;
    public static final int LOCATION = 3;
    public static final int AREA_KILL = 4;
    public static final int MANUAL = 5;
}

