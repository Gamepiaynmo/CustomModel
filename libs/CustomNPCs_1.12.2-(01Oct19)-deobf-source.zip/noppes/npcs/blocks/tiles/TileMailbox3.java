/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileNpcEntity;

public class TileMailbox3
extends TileNpcEntity {
}

