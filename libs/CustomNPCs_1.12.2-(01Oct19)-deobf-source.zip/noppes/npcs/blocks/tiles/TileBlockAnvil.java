/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileNpcEntity;

public class TileBlockAnvil
extends TileNpcEntity {
    public boolean canUpdate() {
        return false;
    }
}

