/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.command.CommandBase
 *  net.minecraft.command.CommandException
 *  net.minecraft.command.ICommandSender
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.world.World
 */
package noppes.npcs.command;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import noppes.npcs.NoppesUtilServer;
import noppes.npcs.api.CommandNoppesBase;
import noppes.npcs.client.EntityUtil;
import noppes.npcs.controllers.DialogController;
import noppes.npcs.controllers.PlayerDataController;
import noppes.npcs.controllers.SyncController;
import noppes.npcs.controllers.data.Dialog;
import noppes.npcs.controllers.data.DialogOption;
import noppes.npcs.controllers.data.PlayerData;
import noppes.npcs.controllers.data.PlayerDialogData;
import noppes.npcs.entity.EntityDialogNpc;
import noppes.npcs.entity.data.DataDisplay;

public class CmdDialog
extends CommandNoppesBase {
    public String getName() {
        return "dialog";
    }

    @Override
    public String getDescription() {
        return "Dialog operations";
    }

    @CommandNoppesBase.SubCommand(desc="force read", usage="<player> <dialog>", permission=2)
    public void read(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        int diagid;
        String playername = args[0];
        try {
            diagid = Integer.parseInt(args[1]);
        }
        catch (NumberFormatException ex) {
            throw new CommandException("DialogID must be an integer", new Object[0]);
        }
        List<PlayerData> data = PlayerDataController.instance.getPlayersData(sender, playername);
        if (data.isEmpty()) {
            throw new CommandException("Unknow player '%s'", new Object[]{playername});
        }
        for (PlayerData playerdata : data) {
            playerdata.dialogData.dialogsRead.add(diagid);
            playerdata.save(true);
        }
    }

    @CommandNoppesBase.SubCommand(desc="force unread dialog", usage="<player> <dialog>", permission=2)
    public void unread(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        int diagid;
        String playername = args[0];
        try {
            diagid = Integer.parseInt(args[1]);
        }
        catch (NumberFormatException ex) {
            throw new CommandException("DialogID must be an integer", new Object[0]);
        }
        List<PlayerData> data = PlayerDataController.instance.getPlayersData(sender, playername);
        if (data.isEmpty()) {
            throw new CommandException("Unknow player '%s'", new Object[]{playername});
        }
        for (PlayerData playerdata : data) {
            playerdata.dialogData.dialogsRead.remove(diagid);
            playerdata.save(true);
        }
    }

    @CommandNoppesBase.SubCommand(desc="reload dialogs from disk", permission=4)
    public void reload(MinecraftServer server, ICommandSender sender, String[] args) {
        new DialogController().load();
        SyncController.syncAllDialogs(server);
    }

    @CommandNoppesBase.SubCommand(desc="show dialog", usage="<player> <dialog> <name>", permission=2)
    public void show(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        int diagid;
        List players = CommandBase.getPlayers((MinecraftServer)server, (ICommandSender)sender, (String)args[0]);
        if (players == null) {
            throw new CommandException("Unknow player '%s'", new Object[]{args[0]});
        }
        try {
            diagid = Integer.parseInt(args[1]);
        }
        catch (NumberFormatException ex) {
            throw new CommandException("DialogID must be an integer: " + args[1], new Object[0]);
        }
        Dialog dialog = DialogController.instance.dialogs.get(diagid);
        if (dialog == null) {
            throw new CommandException("Unknown dialog id: " + args[1], new Object[0]);
        }
        EntityDialogNpc npc = new EntityDialogNpc(sender.getEntityWorld());
        DialogOption option = new DialogOption();
        option.dialogId = diagid;
        option.title = dialog.title;
        npc.dialogs.put(0, option);
        npc.display.setName(args[2]);
        for (EntityPlayer player : players) {
            EntityUtil.Copy((EntityLivingBase)player, (EntityLivingBase)npc);
            NoppesUtilServer.openDialog(player, npc, dialog);
        }
    }
}

