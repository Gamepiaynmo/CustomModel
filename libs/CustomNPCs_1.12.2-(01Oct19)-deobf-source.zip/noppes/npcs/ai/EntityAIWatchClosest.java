/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.ai.EntityLookHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.world.World
 */
package noppes.npcs.ai;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityLookHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;
import noppes.npcs.constants.AiMutex;
import noppes.npcs.entity.EntityNPCInterface;

public class EntityAIWatchClosest
extends EntityAIBase {
    private EntityNPCInterface npc;
    protected Entity closestEntity;
    private float maxDistanceForPlayer;
    private int lookTime;
    private float chance;
    private Class watchedClass;

    public EntityAIWatchClosest(EntityNPCInterface par1EntityLiving, Class par2Class, float par3) {
        this.npc = par1EntityLiving;
        this.watchedClass = par2Class;
        this.maxDistanceForPlayer = par3;
        this.chance = 0.002f;
        this.setMutexBits((int)AiMutex.LOOK);
    }

    public boolean shouldExecute() {
        if (this.npc.getRNG().nextFloat() >= this.chance || this.npc.isInteracting()) {
            return false;
        }
        if (this.npc.getAttackTarget() != null) {
            this.closestEntity = this.npc.getAttackTarget();
        }
        if (this.watchedClass == EntityPlayer.class) {
            this.closestEntity = this.npc.world.getClosestPlayerToEntity((Entity)this.npc, (double)this.maxDistanceForPlayer);
        } else {
            this.closestEntity = this.npc.world.findNearestEntityWithinAABB(this.watchedClass, this.npc.getEntityBoundingBox().grow((double)this.maxDistanceForPlayer, 3.0, (double)this.maxDistanceForPlayer), (Entity)this.npc);
            if (this.closestEntity != null) {
                return this.npc.canSee(this.closestEntity);
            }
        }
        return this.closestEntity != null;
    }

    public boolean shouldContinueExecuting() {
        if (this.npc.isInteracting() || this.npc.isAttacking() || !this.closestEntity.isEntityAlive() || !this.npc.isEntityAlive()) {
            return false;
        }
        return !this.npc.isInRange(this.closestEntity, this.maxDistanceForPlayer) ? false : this.lookTime > 0;
    }

    public void startExecuting() {
        this.lookTime = 60 + this.npc.getRNG().nextInt(60);
    }

    public void resetTask() {
        this.closestEntity = null;
    }

    public void updateTask() {
        this.npc.getLookHelper().setLookPosition(this.closestEntity.posX, this.closestEntity.posY + (double)this.closestEntity.getEyeHeight(), this.closestEntity.posZ, 10.0f, (float)this.npc.getVerticalFaceSpeed());
        --this.lookTime;
    }
}

