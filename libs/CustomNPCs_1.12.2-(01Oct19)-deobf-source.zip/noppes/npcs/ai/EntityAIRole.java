/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ai.EntityAIBase
 */
package noppes.npcs.ai;

import net.minecraft.entity.ai.EntityAIBase;
import noppes.npcs.entity.EntityNPCInterface;
import noppes.npcs.roles.RoleInterface;

public class EntityAIRole
extends EntityAIBase {
    private EntityNPCInterface npc;

    public EntityAIRole(EntityNPCInterface npc) {
        this.npc = npc;
    }

    public boolean shouldExecute() {
        if (this.npc.isKilled() || this.npc.roleInterface == null) {
            return false;
        }
        return this.npc.roleInterface.aiShouldExecute();
    }

    public void startExecuting() {
        this.npc.roleInterface.aiStartExecuting();
    }

    public boolean shouldContinueExecuting() {
        if (this.npc.isKilled() || this.npc.roleInterface == null) {
            return false;
        }
        return this.npc.roleInterface.aiContinueExecute();
    }

    public void updateTask() {
        if (this.npc.roleInterface != null) {
            this.npc.roleInterface.aiUpdateTask();
        }
    }
}

