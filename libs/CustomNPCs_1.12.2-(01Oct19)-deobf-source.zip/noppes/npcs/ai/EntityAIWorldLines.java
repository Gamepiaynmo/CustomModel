/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ai.EntityAIBase
 */
package noppes.npcs.ai;

import java.util.Random;
import net.minecraft.entity.ai.EntityAIBase;
import noppes.npcs.constants.AiMutex;
import noppes.npcs.controllers.data.Line;
import noppes.npcs.entity.EntityNPCInterface;
import noppes.npcs.entity.data.DataAdvanced;

public class EntityAIWorldLines
extends EntityAIBase {
    private EntityNPCInterface npc;
    private int cooldown = 100;

    public EntityAIWorldLines(EntityNPCInterface npc) {
        this.npc = npc;
        this.setMutexBits((int)AiMutex.PASSIVE);
    }

    public boolean shouldExecute() {
        if (this.cooldown > 0) {
            --this.cooldown;
        }
        return !this.npc.isAttacking() && !this.npc.isKilled() && this.npc.advanced.hasWorldLines() && this.npc.getRNG().nextInt(1800) == 1;
    }

    public void startExecuting() {
        this.cooldown = 100;
        this.npc.saySurrounding(this.npc.advanced.getWorldLine());
    }
}

