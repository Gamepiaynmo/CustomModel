/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.ai.EntityJumpHelper
 *  net.minecraft.pathfinding.PathNavigate
 *  net.minecraft.pathfinding.PathNavigateGround
 */
package noppes.npcs.ai;

import java.util.Random;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityJumpHelper;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathNavigateGround;
import noppes.npcs.entity.EntityNPCInterface;
import noppes.npcs.entity.data.DataAI;

public class EntityAIWaterNav
extends EntityAIBase {
    private EntityNPCInterface entity;

    public EntityAIWaterNav(EntityNPCInterface iNpc) {
        this.entity = iNpc;
        ((PathNavigateGround)iNpc.getNavigator()).setCanSwim(true);
    }

    public boolean shouldExecute() {
        if (this.entity.isInWater() || this.entity.isInLava()) {
            if (this.entity.ais.canSwim) {
                return true;
            }
            return this.entity.collidedHorizontally;
        }
        return false;
    }

    public void updateTask() {
        if (this.entity.getRNG().nextFloat() < 0.8f) {
            this.entity.getJumpHelper().setJumping();
        }
    }
}

