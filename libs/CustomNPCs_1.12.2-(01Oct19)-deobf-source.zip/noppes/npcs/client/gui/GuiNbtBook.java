/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.client.renderer.RenderItem
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.JsonToNBT
 *  net.minecraft.nbt.NBTException
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.registry.RegistryNamespacedDefaultedByKey
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.registry.EntityRegistry
 */
package noppes.npcs.client.gui;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.JsonToNBT;
import net.minecraft.nbt.NBTException;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.RegistryNamespacedDefaultedByKey;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import noppes.npcs.client.Client;
import noppes.npcs.client.gui.SubGuiNpcTextArea;
import noppes.npcs.client.gui.util.GuiNPCInterface;
import noppes.npcs.client.gui.util.GuiNpcButton;
import noppes.npcs.client.gui.util.GuiNpcLabel;
import noppes.npcs.client.gui.util.IGuiData;
import noppes.npcs.client.gui.util.SubGuiInterface;
import noppes.npcs.constants.EnumPacketServer;

public class GuiNbtBook
extends GuiNPCInterface
implements IGuiData {
    private int x;
    private int y;
    private int z;
    private TileEntity tile;
    private IBlockState state;
    private ItemStack blockStack;
    private int entityId;
    private Entity entity;
    private NBTTagCompound originalCompound;
    private NBTTagCompound compound;
    private String faultyText = null;
    private String errorMessage = null;

    public GuiNbtBook(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.setBackground("menubg.png");
        this.xSize = 256;
        this.ySize = 216;
    }

    @Override
    public void initGui() {
        super.initGui();
        int y = this.guiTop + 40;
        if (this.state != null) {
            this.addLabel(new GuiNpcLabel(11, "x: " + this.x + ", y: " + y + ", z: " + this.z, this.guiLeft + 60, this.guiTop + 6));
            this.addLabel(new GuiNpcLabel(12, "id: " + Block.REGISTRY.getNameForObject((Object)this.state.getBlock()), this.guiLeft + 60, this.guiTop + 16));
        }
        if (this.entity != null) {
            this.addLabel(new GuiNpcLabel(12, "id: " + (Object)EntityRegistry.getEntry(this.entity.getClass()).getRegistryName(), this.guiLeft + 60, this.guiTop + 6));
        }
        this.addButton(new GuiNpcButton(0, this.guiLeft + 38, this.guiTop + 144, 180, 20, "nbt.edit"));
        this.getButton((int)0).enabled = this.compound != null && !this.compound.hasNoTags();
        this.addLabel(new GuiNpcLabel(0, "", this.guiLeft + 4, this.guiTop + 167));
        this.addLabel(new GuiNpcLabel(1, "", this.guiLeft + 4, this.guiTop + 177));
        this.addButton(new GuiNpcButton(66, this.guiLeft + 128, this.guiTop + 190, 120, 20, "gui.close"));
        this.addButton(new GuiNpcButton(67, this.guiLeft + 4, this.guiTop + 190, 120, 20, "gui.save"));
        if (this.errorMessage != null) {
            this.getButton((int)67).enabled = false;
            int i = this.errorMessage.indexOf(" at: ");
            if (i > 0) {
                this.getLabel((int)0).label = this.errorMessage.substring(0, i);
                this.getLabel((int)1).label = this.errorMessage.substring(i);
            } else {
                this.getLabel((int)0).label = this.errorMessage;
            }
        }
        if (this.getButton((int)67).enabled && this.originalCompound != null) {
            this.getButton((int)67).enabled = !this.originalCompound.equals((Object)this.compound);
        }
    }

    @Override
    protected void actionPerformed(GuiButton guibutton) {
        int id = guibutton.id;
        if (id == 0) {
            if (this.faultyText != null) {
                this.setSubGui(new SubGuiNpcTextArea(this.compound.toString(), this.faultyText).enableHighlighting());
            } else {
                this.setSubGui(new SubGuiNpcTextArea(this.compound.toString()).enableHighlighting());
            }
        }
        if (id == 67) {
            this.getLabel((int)0).label = "Saved";
            if (this.compound.equals((Object)this.originalCompound)) {
                return;
            }
            if (this.tile == null) {
                Client.sendData(EnumPacketServer.NbtBookSaveEntity, new Object[]{this.entityId, this.compound});
                return;
            }
            Client.sendData(EnumPacketServer.NbtBookSaveBlock, new Object[]{this.x, this.y, this.z, this.compound});
            this.originalCompound = this.compound.copy();
            this.getButton((int)67).enabled = false;
        }
        if (id == 66) {
            this.close();
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        if (this.hasSubGui()) {
            return;
        }
        if (this.state != null) {
            GlStateManager.pushMatrix();
            GlStateManager.translate((float)(this.guiLeft + 4), (float)(this.guiTop + 4), (float)0.0f);
            GlStateManager.scale((float)3.0f, (float)3.0f, (float)3.0f);
            RenderHelper.enableGUIStandardItemLighting();
            this.itemRender.renderItemAndEffectIntoGUI(this.blockStack, 0, 0);
            this.itemRender.renderItemOverlays(this.fontRenderer, this.blockStack, 0, 0);
            RenderHelper.disableStandardItemLighting();
            GlStateManager.popMatrix();
        }
        if (this.entity instanceof EntityLivingBase) {
            this.drawNpc((EntityLivingBase)this.entity, 20, 80, 1.0f, 0);
        }
    }

    @Override
    public void closeSubGui(SubGuiInterface gui) {
        super.closeSubGui(gui);
        if (gui instanceof SubGuiNpcTextArea) {
            try {
                this.compound = JsonToNBT.getTagFromJson((String)((SubGuiNpcTextArea)gui).text);
                this.faultyText = null;
                this.errorMessage = null;
            }
            catch (NBTException e) {
                this.errorMessage = e.getLocalizedMessage();
                this.faultyText = ((SubGuiNpcTextArea)gui).text;
            }
            this.initGui();
        }
    }

    @Override
    public void save() {
    }

    @Override
    public void setGuiData(NBTTagCompound compound) {
        if (compound.hasKey("EntityId")) {
            this.entityId = compound.getInteger("EntityId");
            this.entity = this.player.world.getEntityByID(this.entityId);
        } else {
            this.tile = this.player.world.getTileEntity(new BlockPos(this.x, this.y, this.z));
            this.state = this.player.world.getBlockState(new BlockPos(this.x, this.y, this.z));
            this.blockStack = this.state.getBlock().getItem(this.player.world, new BlockPos(this.x, this.y, this.z), this.state);
        }
        this.originalCompound = compound.getCompoundTag("Data");
        this.compound = this.originalCompound.copy();
        this.initGui();
    }
}

