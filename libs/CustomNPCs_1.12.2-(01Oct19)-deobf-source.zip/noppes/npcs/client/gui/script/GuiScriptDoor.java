/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package noppes.npcs.client.gui.script;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import noppes.npcs.blocks.tiles.TileScriptedDoor;
import noppes.npcs.client.Client;
import noppes.npcs.client.gui.script.GuiScriptInterface;
import noppes.npcs.constants.EnumPacketServer;
import noppes.npcs.controllers.IScriptHandler;

public class GuiScriptDoor
extends GuiScriptInterface {
    private TileScriptedDoor script;

    public GuiScriptDoor(int x, int y, int z) {
        this.script = (TileScriptedDoor)this.player.world.getTileEntity(new BlockPos(x, y, z));
        this.handler = this.script;
        Client.sendData(EnumPacketServer.ScriptDoorDataGet, x, y, z);
    }

    @Override
    public void setGuiData(NBTTagCompound compound) {
        this.script.setNBT(compound);
        super.setGuiData(compound);
    }

    @Override
    public void save() {
        super.save();
        BlockPos pos = this.script.getPos();
        Client.sendData(EnumPacketServer.ScriptDoorDataSave, new Object[]{pos.getX(), pos.getY(), pos.getZ(), this.script.getNBT(new NBTTagCompound())});
    }
}

