/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.entity.EntityLivingBase
 */
package noppes.npcs.client.gui;

import java.util.HashSet;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.EntityLivingBase;
import noppes.npcs.client.AssetsBrowser;
import noppes.npcs.client.gui.GuiNpcSelectionInterface;
import noppes.npcs.client.gui.util.GuiNPCStringSlot;
import noppes.npcs.entity.EntityNPCInterface;
import noppes.npcs.entity.data.DataDisplay;

public class GuiNpcTextureOverlays
extends GuiNpcSelectionInterface {
    public GuiNpcTextureOverlays(EntityNPCInterface npc, GuiScreen parent) {
        super(npc, parent, npc.display.getOverlayTexture().isEmpty() ? "customnpcs:textures/overlays/" : npc.display.getOverlayTexture());
        this.title = "Select Overlay";
        this.parent = parent;
    }

    @Override
    public void initGui() {
        super.initGui();
        int index = this.npc.display.getOverlayTexture().lastIndexOf("/");
        if (index > 0) {
            String asset = this.npc.display.getOverlayTexture().substring(index + 1);
            if (this.npc.display.getOverlayTexture().equals(this.assets.getAsset(asset))) {
                this.slot.selected = asset;
            }
        }
    }

    @Override
    public void drawScreen(int i, int j, float f) {
        int l = -50;
        int i1 = this.height / 2 + 30;
        this.drawNpc((EntityLivingBase)this.npc, l, i1, 2.0f, 0);
        super.drawScreen(i, j, f);
    }

    @Override
    public void elementClicked() {
        if (this.dataTextures.contains(this.slot.selected) && this.slot.selected != null) {
            this.npc.display.setOverlayTexture(this.assets.getAsset(this.slot.selected));
        }
    }

    @Override
    public void save() {
    }

    @Override
    public String[] getExtension() {
        return new String[]{"png"};
    }
}

