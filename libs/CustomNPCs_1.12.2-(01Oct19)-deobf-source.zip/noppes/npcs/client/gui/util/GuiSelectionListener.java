/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

public interface GuiSelectionListener {
    public void selected(int var1, String var2);
}

