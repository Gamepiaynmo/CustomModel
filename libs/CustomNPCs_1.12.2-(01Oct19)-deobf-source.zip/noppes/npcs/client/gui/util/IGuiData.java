/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.NBTTagCompound
 */
package noppes.npcs.client.gui.util;

import net.minecraft.nbt.NBTTagCompound;

public interface IGuiData {
    public void setGuiData(NBTTagCompound var1);
}

