/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

import java.util.HashMap;
import java.util.Vector;

public interface IScrollData {
    public void setData(Vector<String> var1, HashMap<String, Integer> var2);

    public void setSelected(String var1);
}

