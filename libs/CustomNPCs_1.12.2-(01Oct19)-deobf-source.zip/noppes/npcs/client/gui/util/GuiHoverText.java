/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.texture.TextureManager
 *  net.minecraft.util.ResourceLocation
 */
package noppes.npcs.client.gui.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;

public class GuiHoverText
extends GuiScreen {
    private int x;
    private int y;
    public int id;
    protected static final ResourceLocation buttonTextures = new ResourceLocation("customnpcs:textures/gui/info.png");
    private String text;

    public GuiHoverText(int id, String text, int x, int y) {
        this.text = text;
        this.id = id;
        this.x = x;
        this.y = y;
    }

    public void drawScreen(int par1, int par2, float par3) {
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.mc.getTextureManager().bindTexture(buttonTextures);
        this.drawTexturedModalRect(this.x, this.y, 0, 0, 12, 12);
        if (this.inArea(this.x, this.y, 12, 12, par1, par2)) {
            ArrayList<String> lines = new ArrayList<String>();
            lines.add(this.text);
            this.drawHoveringText(lines, this.x + 8, this.y + 6, this.fontRenderer);
            GlStateManager.disableLighting();
        }
    }

    public boolean inArea(int x, int y, int width, int height, int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}

