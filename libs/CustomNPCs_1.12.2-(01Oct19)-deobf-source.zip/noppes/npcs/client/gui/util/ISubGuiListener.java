/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.SubGuiInterface;

public interface ISubGuiListener {
    public void subGuiClosed(SubGuiInterface var1);
}

