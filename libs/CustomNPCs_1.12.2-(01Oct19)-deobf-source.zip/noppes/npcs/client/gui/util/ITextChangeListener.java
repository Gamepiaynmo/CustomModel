/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

public interface ITextChangeListener {
    public void textUpdate(String var1);
}

