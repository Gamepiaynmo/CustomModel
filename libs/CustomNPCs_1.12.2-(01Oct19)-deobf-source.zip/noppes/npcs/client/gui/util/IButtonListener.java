/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiButton
 */
package noppes.npcs.client.gui.util;

import net.minecraft.client.gui.GuiButton;

public interface IButtonListener {
    public void actionPerformed(GuiButton var1);
}

