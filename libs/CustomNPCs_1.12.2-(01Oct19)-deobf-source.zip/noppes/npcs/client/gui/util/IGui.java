/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

public interface IGui {
    public int getID();

    public void drawScreen(int var1, int var2);

    public void updateScreen();

    public boolean isActive();
}

