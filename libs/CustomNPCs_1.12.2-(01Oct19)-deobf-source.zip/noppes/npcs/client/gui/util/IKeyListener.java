/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

public interface IKeyListener {
    public void keyTyped(char var1, int var2);
}

