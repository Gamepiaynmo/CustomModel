/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

public interface IJTextAreaListener {
    public void saveText(String var1);
}

