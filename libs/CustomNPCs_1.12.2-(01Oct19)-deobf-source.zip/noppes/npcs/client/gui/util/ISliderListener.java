/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.GuiNpcSlider;

public interface ISliderListener {
    public void mouseDragged(GuiNpcSlider var1);

    public void mousePressed(GuiNpcSlider var1);

    public void mouseReleased(GuiNpcSlider var1);
}

