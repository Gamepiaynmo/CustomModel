/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

public interface IMouseListener {
    public boolean mouseClicked(int var1, int var2, int var3);
}

