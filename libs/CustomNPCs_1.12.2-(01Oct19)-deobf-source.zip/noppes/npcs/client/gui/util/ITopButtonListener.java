/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

public interface ITopButtonListener {
    public void mouseClicked(int var1, int var2, int var3);
}

