/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.GuiCustomScroll;

public interface ICustomScrollListener {
    public void scrollClicked(int var1, int var2, int var3, GuiCustomScroll var4);

    public void scrollDoubleClicked(String var1, GuiCustomScroll var2);
}

