/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.GuiNpcTextField;

public interface ITextfieldListener {
    public void unFocused(GuiNpcTextField var1);
}

