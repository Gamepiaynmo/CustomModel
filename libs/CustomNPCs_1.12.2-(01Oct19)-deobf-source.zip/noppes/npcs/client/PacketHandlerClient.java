/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  com.google.common.util.concurrent.ListenableFuture
 *  io.netty.buffer.ByteBuf
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.toasts.GuiToast
 *  net.minecraft.client.gui.toasts.IToast
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.renderer.ItemModelMesher
 *  net.minecraft.client.renderer.RenderItem
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.passive.EntityVillager
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.nbt.NBTTagList
 *  net.minecraft.network.PacketBuffer
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentTranslation
 *  net.minecraft.util.text.translation.I18n
 *  net.minecraft.village.MerchantRecipeList
 *  net.minecraft.world.World
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.network.FMLNetworkEvent
 *  net.minecraftforge.fml.common.network.FMLNetworkEvent$ClientCustomPacketEvent
 *  net.minecraftforge.fml.common.network.internal.FMLProxyPacket
 */
package noppes.npcs.client;

import com.google.common.util.concurrent.ListenableFuture;
import io.netty.buffer.ByteBuf;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.toasts.GuiToast;
import net.minecraft.client.gui.toasts.IToast;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.PacketBuffer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.World;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraftforge.fml.common.network.internal.FMLProxyPacket;
import noppes.npcs.CommonProxy;
import noppes.npcs.CustomItems;
import noppes.npcs.CustomNpcs;
import noppes.npcs.IChatMessages;
import noppes.npcs.LogWriter;
import noppes.npcs.ModelData;
import noppes.npcs.ModelEyeData;
import noppes.npcs.NBTTags;
import noppes.npcs.NoppesStringUtils;
import noppes.npcs.NoppesUtilPlayer;
import noppes.npcs.PacketHandlerServer;
import noppes.npcs.Server;
import noppes.npcs.ServerEventsHandler;
import noppes.npcs.api.NpcAPI;
import noppes.npcs.api.handler.data.IQuest;
import noppes.npcs.api.item.IItemStack;
import noppes.npcs.api.wrapper.ItemStackWrapper;
import noppes.npcs.client.ClientProxy;
import noppes.npcs.client.EntityUtil;
import noppes.npcs.client.NoppesUtil;
import noppes.npcs.client.RenderChatMessages;
import noppes.npcs.client.controllers.MusicController;
import noppes.npcs.client.gui.GuiAchievement;
import noppes.npcs.client.gui.GuiNpcMobSpawnerAdd;
import noppes.npcs.client.gui.player.GuiCustomChest;
import noppes.npcs.client.gui.player.GuiQuestCompletion;
import noppes.npcs.client.gui.util.GuiContainerNPCInterface;
import noppes.npcs.client.gui.util.GuiNPCInterface;
import noppes.npcs.client.gui.util.IGuiClose;
import noppes.npcs.client.gui.util.IGuiData;
import noppes.npcs.client.gui.util.IGuiError;
import noppes.npcs.client.gui.util.IScrollData;
import noppes.npcs.client.gui.util.SubGuiInterface;
import noppes.npcs.config.ConfigLoader;
import noppes.npcs.constants.EnumGuiType;
import noppes.npcs.constants.EnumPacketClient;
import noppes.npcs.constants.EnumPlayerPacket;
import noppes.npcs.controllers.DialogController;
import noppes.npcs.controllers.QuestController;
import noppes.npcs.controllers.SyncController;
import noppes.npcs.controllers.data.Dialog;
import noppes.npcs.controllers.data.DialogCategory;
import noppes.npcs.controllers.data.MarkData;
import noppes.npcs.controllers.data.PlayerData;
import noppes.npcs.entity.EntityCustomNpc;
import noppes.npcs.entity.EntityDialogNpc;
import noppes.npcs.entity.EntityNPCInterface;
import noppes.npcs.entity.data.DataAdvanced;
import noppes.npcs.entity.data.DataDisplay;
import noppes.npcs.items.ItemScripted;
import noppes.npcs.roles.RoleInterface;

public class PacketHandlerClient
extends PacketHandlerServer {
    @SubscribeEvent
    public void onPacketData(FMLNetworkEvent.ClientCustomPacketEvent event) {
        EntityPlayerSP player = Minecraft.getMinecraft().player;
        if (player == null) {
            return;
        }
        ByteBuf buffer = event.getPacket().payload();
        Minecraft.getMinecraft().addScheduledTask(() -> this.lambda$onPacketData$0(buffer, (EntityPlayer)player));
    }

    private void client(ByteBuf buffer, EntityPlayer player, EnumPacketClient type) throws Exception {
        int config;
        if (type == EnumPacketClient.CHATBUBBLE) {
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(buffer.readInt());
            if (entity == null || !(entity instanceof EntityNPCInterface)) {
                return;
            }
            EntityNPCInterface npc = (EntityNPCInterface)entity;
            if (npc.messages == null) {
                npc.messages = new RenderChatMessages();
            }
            String text = NoppesStringUtils.formatText(Server.readString(buffer), new Object[]{player, npc});
            npc.messages.addMessage(text, npc);
            if (buffer.readBoolean()) {
                player.sendMessage((ITextComponent)new TextComponentTranslation(npc.getName() + ": " + text, new Object[0]));
            }
        } else if (type == EnumPacketClient.CHAT) {
            String str;
            String message = "";
            while ((str = Server.readString(buffer)) != null && !str.isEmpty()) {
                message = message + I18n.translateToLocal((String)str);
            }
            player.sendMessage((ITextComponent)new TextComponentTranslation(message, new Object[0]));
        } else if (type == EnumPacketClient.EYE_BLINK) {
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(buffer.readInt());
            if (entity == null || !(entity instanceof EntityNPCInterface)) {
                return;
            }
            ModelData data = ((EntityCustomNpc)entity).modelData;
            data.eyes.blinkStart = System.currentTimeMillis();
        } else if (type == EnumPacketClient.MESSAGE) {
            TextComponentTranslation title = new TextComponentTranslation(Server.readString(buffer), new Object[0]);
            TextComponentTranslation message = new TextComponentTranslation(Server.readString(buffer), new Object[0]);
            int btype = buffer.readInt();
            Minecraft.getMinecraft().getToastGui().add((IToast)new GuiAchievement((ITextComponent)title, (ITextComponent)message, btype));
        } else if (type == EnumPacketClient.UPDATE_ITEM) {
            int id = buffer.readInt();
            NBTTagCompound compound = Server.readNBT(buffer);
            ItemStack stack = player.inventory.getStackInSlot(id);
            if (!stack.isEmpty()) {
                ((ItemStackWrapper)NpcAPI.Instance().getIItemStack(stack)).setMCNbt(compound);
            }
        } else if (type == EnumPacketClient.SYNC_ADD || type == EnumPacketClient.SYNC_END) {
            int synctype = buffer.readInt();
            NBTTagCompound compound = Server.readNBT(buffer);
            SyncController.clientSync(synctype, compound, type == EnumPacketClient.SYNC_END);
            if (synctype == 8) {
                ClientProxy.playerData.setNBT(compound);
            } else if (synctype == 9) {
                if (player.getServer() == null) {
                    ItemScripted.Resources = NBTTags.getIntegerStringMap(compound.getTagList("List", 10));
                }
                for (Map.Entry<Integer, String> entry : ItemScripted.Resources.entrySet()) {
                    ModelResourceLocation mrl = new ModelResourceLocation(entry.getValue(), "inventory");
                    Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register((Item)CustomItems.scripted_item, entry.getKey().intValue(), mrl);
                    ModelLoader.setCustomModelResourceLocation((Item)CustomItems.scripted_item, (int)entry.getKey(), (ModelResourceLocation)mrl);
                }
            }
        } else if (type == EnumPacketClient.SYNC_UPDATE) {
            int synctype = buffer.readInt();
            NBTTagCompound compound = Server.readNBT(buffer);
            SyncController.clientSyncUpdate(synctype, compound, buffer);
        } else if (type == EnumPacketClient.CHEST_NAME) {
            GuiScreen screen = Minecraft.getMinecraft().currentScreen;
            if (screen instanceof GuiCustomChest) {
                ((GuiCustomChest)screen).title = I18n.translateToLocal((String)Server.readString(buffer));
            }
        } else if (type == EnumPacketClient.SYNC_REMOVE) {
            int synctype = buffer.readInt();
            int id = buffer.readInt();
            SyncController.clientSyncRemove(synctype, id);
        } else if (type == EnumPacketClient.MARK_DATA) {
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(buffer.readInt());
            if (entity == null || !(entity instanceof EntityLivingBase)) {
                return;
            }
            MarkData data = MarkData.get((EntityLivingBase)entity);
            data.setNBT(Server.readNBT(buffer));
        } else if (type == EnumPacketClient.DIALOG) {
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(buffer.readInt());
            if (entity == null || !(entity instanceof EntityNPCInterface)) {
                return;
            }
            Dialog dialog = DialogController.instance.dialogs.get(buffer.readInt());
            NoppesUtil.openDialog(dialog, (EntityNPCInterface)entity, player);
        } else if (type == EnumPacketClient.DIALOG_DUMMY) {
            EntityDialogNpc npc = new EntityDialogNpc(player.world);
            npc.display.setName(Server.readString(buffer));
            EntityUtil.Copy((EntityLivingBase)player, (EntityLivingBase)npc);
            Dialog dialog = new Dialog(null);
            dialog.readNBT(Server.readNBT(buffer));
            NoppesUtil.openDialog(dialog, npc, player);
        } else if (type == EnumPacketClient.QUEST_COMPLETION) {
            int id = buffer.readInt();
            IQuest quest = QuestController.instance.get(id);
            if (!quest.getCompleteText().isEmpty()) {
                NoppesUtil.openGUI(player, new GuiQuestCompletion(quest));
            } else {
                NoppesUtilPlayer.sendData(EnumPlayerPacket.QuestCompletion, id);
            }
        } else if (type == EnumPacketClient.EDIT_NPC) {
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(buffer.readInt());
            if (entity == null || !(entity instanceof EntityNPCInterface)) {
                NoppesUtil.setLastNpc(null);
            } else {
                NoppesUtil.setLastNpc((EntityNPCInterface)entity);
            }
        } else if (type == EnumPacketClient.PLAY_MUSIC) {
            MusicController.Instance.playMusic(Server.readString(buffer), (Entity)player);
        } else if (type == EnumPacketClient.PLAY_SOUND) {
            MusicController.Instance.playSound(SoundCategory.VOICE, Server.readString(buffer), buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readFloat(), buffer.readFloat());
        } else if (type == EnumPacketClient.UPDATE_NPC) {
            NBTTagCompound compound = Server.readNBT(buffer);
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(compound.getInteger("EntityId"));
            if (entity == null || !(entity instanceof EntityNPCInterface)) {
                return;
            }
            ((EntityNPCInterface)entity).readSpawnData(compound);
        } else if (type == EnumPacketClient.ROLE) {
            NBTTagCompound compound = Server.readNBT(buffer);
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(compound.getInteger("EntityId"));
            if (entity == null || !(entity instanceof EntityNPCInterface)) {
                return;
            }
            ((EntityNPCInterface)entity).advanced.setRole(compound.getInteger("Role"));
            ((EntityNPCInterface)entity).roleInterface.readFromNBT(compound);
            NoppesUtil.setLastNpc((EntityNPCInterface)entity);
        } else if (type == EnumPacketClient.GUI) {
            EnumGuiType gui = EnumGuiType.values()[buffer.readInt()];
            CustomNpcs.proxy.openGui(NoppesUtil.getLastNpc(), gui, buffer.readInt(), buffer.readInt(), buffer.readInt());
        } else if (type == EnumPacketClient.PARTICLE) {
            NoppesUtil.spawnParticle(buffer);
        } else if (type == EnumPacketClient.DELETE_NPC) {
            Entity entity = Minecraft.getMinecraft().world.getEntityByID(buffer.readInt());
            if (entity == null || !(entity instanceof EntityNPCInterface)) {
                return;
            }
            ((EntityNPCInterface)entity).delete();
        } else if (type == EnumPacketClient.SCROLL_LIST) {
            NoppesUtil.setScrollList(buffer);
        } else if (type == EnumPacketClient.SCROLL_DATA) {
            NoppesUtil.setScrollData(buffer);
        } else if (type == EnumPacketClient.SCROLL_DATA_PART) {
            NoppesUtil.addScrollData(buffer);
        } else if (type == EnumPacketClient.SCROLL_SELECTED) {
            GuiScreen gui = Minecraft.getMinecraft().currentScreen;
            if (gui == null || !(gui instanceof IScrollData)) {
                return;
            }
            String selected = Server.readString(buffer);
            ((IScrollData)gui).setSelected(selected);
        } else if (type == EnumPacketClient.CLONE) {
            NBTTagCompound compound = Server.readNBT(buffer);
            NoppesUtil.openGUI(player, new GuiNpcMobSpawnerAdd(compound));
        } else if (type == EnumPacketClient.GUI_DATA) {
            GuiScreen gui = Minecraft.getMinecraft().currentScreen;
            if (gui == null) {
                return;
            }
            if (gui instanceof GuiNPCInterface && ((GuiNPCInterface)gui).hasSubGui()) {
                gui = ((GuiNPCInterface)gui).getSubGui();
            } else if (gui instanceof GuiContainerNPCInterface && ((GuiContainerNPCInterface)gui).hasSubGui()) {
                gui = ((GuiContainerNPCInterface)gui).getSubGui();
            }
            if (gui instanceof IGuiData) {
                ((IGuiData)gui).setGuiData(Server.readNBT(buffer));
            }
        } else if (type == EnumPacketClient.GUI_UPDATE) {
            GuiScreen gui = Minecraft.getMinecraft().currentScreen;
            if (gui == null) {
                return;
            }
            gui.initGui();
        } else if (type == EnumPacketClient.GUI_ERROR) {
            GuiScreen gui = Minecraft.getMinecraft().currentScreen;
            if (gui == null || !(gui instanceof IGuiError)) {
                return;
            }
            int i = buffer.readInt();
            NBTTagCompound compound = Server.readNBT(buffer);
            ((IGuiError)gui).setError(i, compound);
        } else if (type == EnumPacketClient.GUI_CLOSE) {
            GuiScreen gui = Minecraft.getMinecraft().currentScreen;
            if (gui == null) {
                return;
            }
            if (gui instanceof IGuiClose) {
                int i = buffer.readInt();
                NBTTagCompound compound = Server.readNBT(buffer);
                ((IGuiClose)gui).setClose(i, compound);
            }
            Minecraft mc = Minecraft.getMinecraft();
            mc.displayGuiScreen(null);
            mc.setIngameFocus();
        } else if (type == EnumPacketClient.VILLAGER_LIST) {
            MerchantRecipeList merchantrecipelist = MerchantRecipeList.readFromBuf((PacketBuffer)new PacketBuffer(buffer));
            ServerEventsHandler.Merchant.setRecipes(merchantrecipelist);
        } else if (type == EnumPacketClient.CONFIG && (config = buffer.readInt()) == 0) {
            String font = Server.readString(buffer);
            int size = buffer.readInt();
            Runnable run = () -> {
                if (!font.isEmpty()) {
                    CustomNpcs.FontType = font;
                    CustomNpcs.FontSize = size;
                    ClientProxy.Font.clear();
                    ClientProxy.Font = new ClientProxy.FontContainer(CustomNpcs.FontType, CustomNpcs.FontSize);
                    CustomNpcs.Config.updateConfig();
                    player.sendMessage((ITextComponent)new TextComponentTranslation("Font set to %s", new Object[]{ClientProxy.Font.getName()}));
                } else {
                    player.sendMessage((ITextComponent)new TextComponentTranslation("Current font is %s", new Object[]{ClientProxy.Font.getName()}));
                }
            };
            Minecraft.getMinecraft().addScheduledTask(run);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private /* synthetic */ void lambda$onPacketData$0(ByteBuf buffer, EntityPlayer player) {
        EnumPacketClient type = null;
        try {
            type = EnumPacketClient.values()[buffer.readInt()];
            LogWriter.debug("Received: " + (Object)((Object)type));
            this.client(buffer, player, type);
        }
        catch (Exception e) {
            LogWriter.error("Error with EnumPacketClient." + (Object)((Object)type), e);
        }
        finally {
            buffer.release();
        }
    }
}

