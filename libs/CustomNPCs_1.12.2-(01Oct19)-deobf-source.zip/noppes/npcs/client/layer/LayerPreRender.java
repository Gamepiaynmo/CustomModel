/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.client.layer;

import noppes.npcs.entity.EntityCustomNpc;

public interface LayerPreRender {
    public void preRender(EntityCustomNpc var1);
}

