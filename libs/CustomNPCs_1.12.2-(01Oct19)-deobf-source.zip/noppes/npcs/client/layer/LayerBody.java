/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.util.math.MathHelper
 */
package noppes.npcs.client.layer;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.util.math.MathHelper;
import noppes.npcs.ModelData;
import noppes.npcs.ModelPartData;
import noppes.npcs.client.layer.LayerInterface;
import noppes.npcs.client.model.Model2DRenderer;
import noppes.npcs.client.model.ModelPlaneRenderer;
import noppes.npcs.constants.EnumParts;
import noppes.npcs.entity.EntityCustomNpc;

public class LayerBody
extends LayerInterface {
    private Model2DRenderer lWing;
    private Model2DRenderer rWing;
    private Model2DRenderer breasts;
    private ModelRenderer breasts2;
    private ModelRenderer breasts3;
    private ModelPlaneRenderer skirt;
    private Model2DRenderer fin;

    public LayerBody(RenderLiving render) {
        super(render);
        this.createParts();
    }

    private void createParts() {
        this.lWing = new Model2DRenderer((ModelBase)this.model, 56.0f, 16.0f, 8, 16);
        this.lWing.mirror = true;
        this.lWing.setRotationPoint(2.0f, 2.5f, 1.0f);
        this.lWing.setRotationOffset(8.0f, 14.0f, 0.0f);
        this.setRotation(this.lWing, 0.7141593f, -0.5235988f, -0.5090659f);
        this.rWing = new Model2DRenderer((ModelBase)this.model, 56.0f, 16.0f, 8, 16);
        this.rWing.setRotationPoint(-2.0f, 2.5f, 1.0f);
        this.rWing.setRotationOffset(-8.0f, 14.0f, 0.0f);
        this.setRotation(this.rWing, 0.7141593f, 0.5235988f, 0.5090659f);
        this.breasts = new Model2DRenderer((ModelBase)this.model, 20.0f, 22.0f, 8, 3);
        this.breasts.setRotationPoint(-3.6f, 5.2f, -3.0f);
        this.breasts.setScale(0.17f, 0.19f);
        this.breasts.setThickness(1.0f);
        this.breasts2 = new ModelRenderer((ModelBase)this.model);
        Model2DRenderer bottom = new Model2DRenderer((ModelBase)this.model, 20.0f, 22.0f, 8, 4);
        bottom.setRotationPoint(-3.6f, 5.0f, -3.1f);
        bottom.setScale(0.225f, 0.2f);
        bottom.setThickness(2.0f);
        bottom.rotateAngleX = -0.31415927f;
        this.breasts2.addChild((ModelRenderer)bottom);
        this.breasts3 = new ModelRenderer((ModelBase)this.model);
        Model2DRenderer right = new Model2DRenderer((ModelBase)this.model, 20.0f, 23.0f, 3, 2);
        right.setRotationPoint(-3.8f, 5.3f, -3.6f);
        right.setScale(0.12f, 0.14f);
        right.setThickness(1.75f);
        this.breasts3.addChild((ModelRenderer)right);
        Model2DRenderer right2 = new Model2DRenderer((ModelBase)this.model, 20.0f, 22.0f, 3, 1);
        right2.setRotationPoint(-3.79f, 4.1f, -3.14f);
        right2.setScale(0.06f, 0.07f);
        right2.setThickness(1.75f);
        right2.rotateAngleX = 0.34906584f;
        this.breasts3.addChild((ModelRenderer)right2);
        Model2DRenderer right3 = new Model2DRenderer((ModelBase)this.model, 20.0f, 24.0f, 3, 1);
        right3.setRotationPoint(-3.79f, 5.3f, -3.6f);
        right3.setScale(0.06f, 0.07f);
        right3.setThickness(1.75f);
        right3.rotateAngleX = -0.34906584f;
        this.breasts3.addChild((ModelRenderer)right3);
        Model2DRenderer right4 = new Model2DRenderer((ModelBase)this.model, 21.0f, 23.0f, 1, 2);
        right4.setRotationPoint(-1.8f, 5.3f, -3.14f);
        right4.setScale(0.12f, 0.14f);
        right4.setThickness(1.75f);
        right4.rotateAngleY = 0.34906584f;
        this.breasts3.addChild((ModelRenderer)right4);
        Model2DRenderer left = new Model2DRenderer((ModelBase)this.model, 25.0f, 23.0f, 3, 2);
        left.setRotationPoint(0.8f, 5.3f, -3.6f);
        left.setScale(0.12f, 0.14f);
        left.setThickness(1.75f);
        this.breasts3.addChild((ModelRenderer)left);
        Model2DRenderer left2 = new Model2DRenderer((ModelBase)this.model, 25.0f, 22.0f, 3, 1);
        left2.setRotationPoint(0.81f, 4.1f, -3.18f);
        left2.setScale(0.06f, 0.07f);
        left2.setThickness(1.75f);
        left2.rotateAngleX = 0.34906584f;
        this.breasts3.addChild((ModelRenderer)left2);
        Model2DRenderer left3 = new Model2DRenderer((ModelBase)this.model, 25.0f, 24.0f, 3, 1);
        left3.setRotationPoint(0.81f, 5.3f, -3.6f);
        left3.setScale(0.06f, 0.07f);
        left3.setThickness(1.75f);
        left3.rotateAngleX = -0.34906584f;
        this.breasts3.addChild((ModelRenderer)left3);
        Model2DRenderer left4 = new Model2DRenderer((ModelBase)this.model, 24.0f, 23.0f, 1, 2);
        left4.setRotationPoint(0.8f, 5.3f, -3.6f);
        left4.setScale(0.12f, 0.14f);
        left4.setThickness(1.75f);
        left4.rotateAngleY = -0.34906584f;
        this.breasts3.addChild((ModelRenderer)left4);
        this.skirt = new ModelPlaneRenderer((ModelBase)this.model, 58, 18);
        this.skirt.addSidePlane(0.0f, 0.0f, 0.0f, 9, 2);
        ModelPlaneRenderer part1 = new ModelPlaneRenderer((ModelBase)this.model, 58, 18);
        part1.addSidePlane(2.0f, 0.0f, 0.0f, 9, 2);
        part1.rotateAngleY = -1.5707964f;
        this.skirt.addChild((ModelRenderer)part1);
        this.skirt.setRotationPoint(2.4f, 8.8f, 0.0f);
        this.setRotation(this.skirt, 0.3f, -0.2f, -0.2f);
        this.fin = new Model2DRenderer((ModelBase)this.model, 56.0f, 20.0f, 8, 12);
        this.fin.setRotationPoint(-0.5f, 12.0f, 10.0f);
        this.fin.setScale(0.74f);
        this.fin.rotateAngleY = 1.5707964f;
    }

    @Override
    public void render(float par2, float par3, float par4, float par5, float par6, float par7) {
        this.model.bipedBody.postRender(0.0625f);
        this.renderSkirt(par7);
        this.renderWings(par7);
        this.renderFin(par7);
        this.renderBreasts(par7);
    }

    private void renderWings(float par7) {
        ModelPartData data = this.playerdata.getPartData(EnumParts.WINGS);
        if (data == null) {
            return;
        }
        this.preRender(data);
        this.rWing.render(par7);
        this.lWing.render(par7);
    }

    private void renderSkirt(float par7) {
        ModelPartData data = this.playerdata.getPartData(EnumParts.SKIRT);
        if (data == null) {
            return;
        }
        this.preRender(data);
        GlStateManager.pushMatrix();
        GlStateManager.scale((float)1.7f, (float)1.04f, (float)1.6f);
        for (int i = 0; i < 10; ++i) {
            GlStateManager.rotate((float)36.0f, (float)0.0f, (float)1.0f, (float)0.0f);
            this.skirt.render(par7);
        }
        GlStateManager.popMatrix();
    }

    private void renderFin(float par7) {
        ModelPartData data = this.playerdata.getPartData(EnumParts.FIN);
        if (data == null) {
            return;
        }
        this.preRender(data);
        this.fin.render(par7);
    }

    private void renderBreasts(float par7) {
        ModelPartData data = this.playerdata.getPartData(EnumParts.BREASTS);
        if (data == null) {
            return;
        }
        data.playerTexture = true;
        this.preRender(data);
        if (data.type == 0) {
            this.breasts.render(par7);
        }
        if (data.type == 1) {
            this.breasts2.render(par7);
        }
        if (data.type == 2) {
            this.breasts3.render(par7);
        }
    }

    @Override
    public void rotate(float par1, float par2, float par3, float par4, float par5, float par6) {
        this.rWing.rotateAngleX = 0.7141593f;
        this.rWing.rotateAngleZ = 0.5090659f;
        this.lWing.rotateAngleX = 0.7141593f;
        this.lWing.rotateAngleZ = -0.5090659f;
        float motion = Math.abs(MathHelper.sin((float)(par1 * 0.033f + 3.1415927f)) * 0.4f) * par2;
        if (!this.npc.onGround || (double)motion > 0.01) {
            float speed = 0.55f + 0.5f * motion;
            float y = MathHelper.sin((float)(par3 * 0.55f));
            this.rWing.rotateAngleZ += y * 0.5f * speed;
            this.rWing.rotateAngleX += y * 0.5f * speed;
            this.lWing.rotateAngleZ -= y * 0.5f * speed;
            this.lWing.rotateAngleX += y * 0.5f * speed;
        } else {
            this.lWing.rotateAngleZ += MathHelper.cos((float)(par3 * 0.09f)) * 0.05f + 0.05f;
            this.rWing.rotateAngleZ -= MathHelper.cos((float)(par3 * 0.09f)) * 0.05f + 0.05f;
            this.lWing.rotateAngleX += MathHelper.sin((float)(par3 * 0.067f)) * 0.05f;
            this.rWing.rotateAngleX += MathHelper.sin((float)(par3 * 0.067f)) * 0.05f;
        }
        this.setRotation(this.skirt, 0.3f, -0.2f, -0.2f);
        this.skirt.rotateAngleX += this.model.bipedLeftArm.rotateAngleX * 0.04f;
        this.skirt.rotateAngleZ += this.model.bipedLeftArm.rotateAngleX * 0.06f;
        this.skirt.rotateAngleZ -= MathHelper.cos((float)(par3 * 0.09f)) * 0.04f - 0.05f;
    }
}

