/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.EntityLivingBase
 */
package noppes.npcs.client.renderer;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import noppes.npcs.client.renderer.RenderNPCInterface;
import noppes.npcs.entity.EntityNPCInterface;
import noppes.npcs.entity.data.DataDisplay;

public class RenderNpcDragon<T extends EntityNPCInterface>
extends RenderNPCInterface<T> {
    public RenderNpcDragon(ModelBase model, float f) {
        super(model, f);
    }

    @Override
    protected void preRenderCallback(T npc, float f) {
        GlStateManager.translate((float)0.0f, (float)0.0f, (float)(0.120000005f * (float)((EntityNPCInterface)npc).display.getSize()));
        super.preRenderCallback(npc, f);
    }
}

