/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.layers.LayerRenderer
 */
package noppes.npcs.client.renderer;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import noppes.npcs.client.layer.LayerSlimeNpc;
import noppes.npcs.client.renderer.RenderNPCInterface;

public class RenderNpcSlime
extends RenderNPCInterface {
    private ModelBase scaleAmount;

    public RenderNpcSlime(ModelBase par1ModelBase, ModelBase par2ModelBase, float par3) {
        super(par1ModelBase, par3);
        this.scaleAmount = par2ModelBase;
        this.addLayer((LayerRenderer)new LayerSlimeNpc(this));
    }
}

