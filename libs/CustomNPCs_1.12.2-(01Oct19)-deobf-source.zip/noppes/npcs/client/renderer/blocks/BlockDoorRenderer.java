/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockDoor
 *  net.minecraft.block.BlockDoor$EnumDoorHalf
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.properties.PropertyBool
 *  net.minecraft.block.properties.PropertyDirection
 *  net.minecraft.block.properties.PropertyEnum
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.renderer.BlockModelRenderer
 *  net.minecraft.client.renderer.BlockModelShapes
 *  net.minecraft.client.renderer.BlockRendererDispatcher
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.client.renderer.block.model.IBakedModel
 *  net.minecraft.client.renderer.texture.TextureMap
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 */
package noppes.npcs.client.renderer.blocks;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.BlockModelRenderer;
import net.minecraft.client.renderer.BlockModelShapes;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import noppes.npcs.CustomItems;
import noppes.npcs.blocks.BlockNpcDoorInterface;
import noppes.npcs.blocks.tiles.TileDoor;
import noppes.npcs.client.renderer.blocks.BlockRendererInterface;

public class BlockDoorRenderer
extends BlockRendererInterface {
    private static Random random = new Random();

    public void render(TileEntity te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
        TileDoor tile = (TileDoor)te;
        IBlockState original = CustomItems.scriptedDoor.getStateFromMeta(tile.getBlockMetadata());
        BlockPos lowerPos = tile.getPos();
        if (original.getValue((IProperty)BlockDoor.HALF) == BlockDoor.EnumDoorHalf.UPPER) {
            lowerPos = tile.getPos().down();
        }
        BlockPos upperPos = lowerPos.up();
        TileDoor lowerTile = (TileDoor)this.getWorld().getTileEntity(lowerPos);
        TileDoor upperTile = (TileDoor)this.getWorld().getTileEntity(upperPos);
        if (lowerTile == null || upperTile == null) {
            return;
        }
        IBlockState lowerState = CustomItems.scriptedDoor.getStateFromMeta(lowerTile.getBlockMetadata());
        IBlockState upperState = CustomItems.scriptedDoor.getStateFromMeta(upperTile.getBlockMetadata());
        int meta = BlockNpcDoorInterface.combineMetadata((IBlockAccess)this.getWorld(), (BlockPos)tile.getPos());
        Block b = lowerTile.blockModel;
        if (this.overrideModel()) {
            b = CustomItems.scriptedDoor;
        }
        IBlockState state = b.getStateFromMeta(meta);
        state = state.withProperty((IProperty)BlockDoor.HALF, original.getValue((IProperty)BlockDoor.HALF));
        state = state.withProperty((IProperty)BlockDoor.FACING, lowerState.getValue((IProperty)BlockDoor.FACING));
        state = state.withProperty((IProperty)BlockDoor.OPEN, lowerState.getValue((IProperty)BlockDoor.OPEN));
        state = state.withProperty((IProperty)BlockDoor.HINGE, upperState.getValue((IProperty)BlockDoor.HINGE));
        state = state.withProperty((IProperty)BlockDoor.POWERED, upperState.getValue((IProperty)BlockDoor.POWERED));
        GlStateManager.pushMatrix();
        RenderHelper.enableStandardItemLighting();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.translate((double)(x + 0.5), (double)y, (double)(z + 0.5));
        GlStateManager.rotate((float)-90.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        this.renderBlock(tile, b, state);
        GlStateManager.disableAlpha();
        GlStateManager.popMatrix();
    }

    private void renderBlock(TileDoor tile, Block b, IBlockState state) {
        this.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        GlStateManager.translate((float)-0.5f, (float)0.0f, (float)0.5f);
        BlockRendererDispatcher dispatcher = Minecraft.getMinecraft().getBlockRendererDispatcher();
        IBakedModel ibakedmodel = dispatcher.getBlockModelShapes().getModelForState(state);
        if (ibakedmodel == null) {
            dispatcher.renderBlockBrightness(state, 1.0f);
        } else {
            dispatcher.getBlockModelRenderer().renderModelBrightness(ibakedmodel, state, 1.0f, true);
        }
    }

    private boolean overrideModel() {
        ItemStack held = Minecraft.getMinecraft().player.getHeldItemMainhand();
        if (held == null) {
            return false;
        }
        return held.getItem() == CustomItems.wand || held.getItem() == CustomItems.scripter || held.getItem() == CustomItems.scriptedDoorTool;
    }
}

