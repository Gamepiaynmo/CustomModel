/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.ability;

import noppes.npcs.ability.AbstractAbility;
import noppes.npcs.ability.IAbilityUpdate;
import noppes.npcs.constants.EnumAbilityType;
import noppes.npcs.entity.EntityNPCInterface;

public class AbilityTeleport
extends AbstractAbility
implements IAbilityUpdate {
    public AbilityTeleport(EntityNPCInterface entity) {
        super(entity);
    }

    @Override
    public boolean isActive() {
        return false;
    }

    @Override
    public void update() {
    }

    @Override
    public boolean isType(EnumAbilityType type) {
        return type == EnumAbilityType.UPDATE;
    }
}

