/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.ability;

import noppes.npcs.ability.IAbility;

public interface IAbilityUpdate
extends IAbility {
    public boolean isActive();

    public void update();
}

