/*
 * Decompiled with CFR 0.146.
 */
package noppes.npcs.ability;

public interface IAbility {
}

