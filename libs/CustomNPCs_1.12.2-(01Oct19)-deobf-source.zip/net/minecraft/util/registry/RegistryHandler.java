/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.crafting.IRecipe
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.registry.RegistryNamespaced
 */
package net.minecraft.util.registry;

import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.RegistryNamespaced;

public class RegistryHandler {
    public static void remove(RegistryNamespaced<ResourceLocation, IRecipe> registry, ResourceLocation loc, Object ob) {
    }
}

